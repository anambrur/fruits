import React from "react";
import ShopSearch from "../Components/ShopSearch";
import ShopSidebar from "../Components/ShopSidebar";
import FruitItem from './../Components/FruitItem';

export default function ShopBody() {
  return (
    <>
      <div className="container-fluid fruite py-5">
        <div className="container py-5">
          <h1 className="mb-4">Fresh fruits shop</h1>
          <div className="row g-4">
            <div className="col-lg-12">
              <ShopSearch />

              <div className="row g-4">
                <ShopSidebar />

                <div className="col-lg-9">
                  <div className="row g-4 justify-content-center">
                    <FruitItem />
                    <FruitItem />
                    <FruitItem />
                    <FruitItem />
                    <FruitItem />
                    <FruitItem />
                    <FruitItem />
                    <FruitItem />

                    <div className="col-12">
                      <div className="pagination d-flex justify-content-center mt-5">
                        <a href="#" className="rounded">
                          «
                        </a>
                        <a href="#" className="active rounded">
                          1
                        </a>
                        <a href="#" className="rounded">
                          2
                        </a>
                        <a href="#" className="rounded">
                          3
                        </a>
                        <a href="#" className="rounded">
                          4
                        </a>
                        <a href="#" className="rounded">
                          5
                        </a>
                        <a href="#" className="rounded">
                          6
                        </a>
                        <a href="#" className="rounded">
                          »
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
